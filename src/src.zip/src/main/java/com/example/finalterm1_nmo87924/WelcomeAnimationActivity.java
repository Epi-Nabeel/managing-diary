package com.example.finalterm1_nmo87924;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class WelcomeAnimationActivity extends AppCompatActivity {
    private static final int ANIMATION_DURATION = 5000;
    private static final String PREFERENCES_NAME = "AppUsagePrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_animation);

        ImageView animationImageView = findViewById(R.id.animationImageView);
        TextView usageTimeLabel = findViewById(R.id.textUsageTime);

        animationImageView.setBackgroundResource(R.drawable.animation_list);

        AnimationDrawable animationDrawable = (AnimationDrawable) animationImageView.getBackground();

        animationImageView.post(() -> {
            animationDrawable.stop();
            animationDrawable.start();
        });

        SharedPreferences prefs = getSharedPreferences(PREFERENCES_NAME, MODE_PRIVATE);
        long firstLaunchTime = prefs.getLong("firstLaunchTime", System.currentTimeMillis());

        if (!prefs.contains("firstLaunchTime")) {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putLong("firstLaunchTime", firstLaunchTime);
            editor.apply();
        }

        // Calculate the app usage time in seconds
        long currentTime = System.currentTimeMillis();
        long usageSeconds = (currentTime - firstLaunchTime) / 1000;

        // Display the usage time
        usageTimeLabel.setText("You have been using this app for " + usageSeconds + " seconds.");

        // Navigate to the next activity after the animation finishes
        new Handler().postDelayed(() -> {
            Intent intent = new Intent(WelcomeAnimationActivity.this, DiaryInputActivity.class);
            startActivity(intent);
            finish();
        }, ANIMATION_DURATION);
    }
}
