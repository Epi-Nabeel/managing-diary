package com.example.finalterm1_nmo87924;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class WebBrowserActivity extends AppCompatActivity {
    private EditText urlInput;
    private Button openBrowserButton, nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_browser);

        urlInput = findViewById(R.id.editUrl);
        openBrowserButton = findViewById(R.id.btnOpenBrowser);
        nextButton = findViewById(R.id.btnNext);

        openBrowserButton.setOnClickListener(view -> {
            String url = urlInput.getText().toString().trim();

            if (url.isEmpty()) {
                url = "https://www.youtube.com";
            } else if (!url.startsWith("http")) {
                url = "https://" + url;
            }

            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(browserIntent);
        });

        nextButton.setOnClickListener(view -> {
            Intent intent = new Intent(WebBrowserActivity.this, SettingsAgainActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
