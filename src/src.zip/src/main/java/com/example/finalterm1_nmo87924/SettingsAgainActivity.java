package com.example.finalterm1_nmo87924;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsAgainActivity extends AppCompatActivity {
    private EditText userNameInput, passwordInput;
    private Button confirmButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings_again);

        userNameInput = findViewById(R.id.editUserName);
        passwordInput = findViewById(R.id.editPassword);
        confirmButton = findViewById(R.id.btnConfirm);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String currentUserName = prefs.getString("userName", "");
        String currentPassword = prefs.getString("password", "");

        userNameInput.setText(currentUserName);
        passwordInput.setText(currentPassword);

        confirmButton.setOnClickListener(view -> {
            String newUserName = userNameInput.getText().toString().trim();
            String newPassword = passwordInput.getText().toString().trim();

            if (TextUtils.isEmpty(newUserName)) {
                Toast.makeText(this, "Please enter a valid name.", Toast.LENGTH_SHORT).show();
            } else if (newPassword.length() < 4) {
                Toast.makeText(this, "Password must be at least 4 digits.", Toast.LENGTH_SHORT).show();
            } else {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("userName", newUserName);
                editor.putString("password", newPassword);
                editor.apply();

                Toast.makeText(this, "Settings updated successfully.", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(SettingsAgainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
