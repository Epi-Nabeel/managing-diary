package com.example.finalterm1_nmo87924;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    private EditText userNameInput, passwordInput;
    private Button confirmButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        if (prefs.contains("userName") && prefs.contains("password")) {
            navigateToLogin();
            return;
        }

        setContentView(R.layout.activity_settings);

        userNameInput = findViewById(R.id.editUserName);
        passwordInput = findViewById(R.id.editPassword);
        confirmButton = findViewById(R.id.btnConfirm);

        confirmButton.setOnClickListener(view -> {
            String userName = userNameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (TextUtils.isEmpty(userName)) {
                Toast.makeText(this, "Please enter your name.", Toast.LENGTH_SHORT).show();
            } else if (password.length() < 4) {
                Toast.makeText(this, "Password must be at least 4 digits long.", Toast.LENGTH_SHORT).show();
            } else {
                SharedPreferences.Editor editor = prefs.edit();
                editor.putString("userName", userName);
                editor.putString("password", password);
                editor.putLong("firstLaunchTime", System.currentTimeMillis());
                editor.apply();

                navigateToLogin();
            }
        });
    }

    private void navigateToLogin() {
        Intent intent = new Intent(SettingsActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
