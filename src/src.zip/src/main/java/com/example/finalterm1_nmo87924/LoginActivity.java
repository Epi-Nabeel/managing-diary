package com.example.finalterm1_nmo87924;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;

public class LoginActivity extends AppCompatActivity {
    private EditText passwordInput;
    private TextView errorLabel, userNameLabel;
    private ImageView diaryImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        passwordInput = findViewById(R.id.editPassword);
        errorLabel = findViewById(R.id.textError);
        userNameLabel = findViewById(R.id.textUserName);
        diaryImage = findViewById(R.id.imageDiary);

        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String savedUsername = prefs.getString("userName", "User");

        userNameLabel.setText("Hello, " + savedUsername + "!");



        String savedPassword = prefs.getString("password", "");

        diaryImage.setOnClickListener(view -> {
            String enteredPassword = passwordInput.getText().toString().trim();

            if (enteredPassword.equals(savedPassword)) {
                Intent intent = new Intent(LoginActivity.this, WelcomeAnimationActivity.class);
                startActivity(intent);
                finish();
            } else {
                errorLabel.setText("Incorrect password. Please try again.");
                errorLabel.setVisibility(android.view.View.VISIBLE);
            }
        });
    }
}
