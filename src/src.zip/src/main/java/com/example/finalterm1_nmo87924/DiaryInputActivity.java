package com.example.finalterm1_nmo87924;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class DiaryInputActivity extends AppCompatActivity {
    private EditText diaryInput;
    private Button confirmButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_diary_input);

        diaryInput = findViewById(R.id.editDiary);
        confirmButton = findViewById(R.id.btnConfirm);

        SharedPreferences prefs = getSharedPreferences("DiaryPrefs", MODE_PRIVATE);

        String today = Utils.getCurrentDate();
        String existingEntry = prefs.getString(today, "");
        diaryInput.setText(existingEntry);

        confirmButton.setOnClickListener(view -> {
            String diaryText = diaryInput.getText().toString().trim();
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(today, diaryText);
            editor.apply();

            Intent intent = new Intent(DiaryInputActivity.this, BrowserActivity.class);
            startActivity(intent);
            finish();
        });
    }
}