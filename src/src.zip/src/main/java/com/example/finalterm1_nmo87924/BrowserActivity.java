package com.example.finalterm1_nmo87924;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class BrowserActivity extends AppCompatActivity {
    private TextView diaryDisplay;
    private Button selectDateButton, nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browser);

        diaryDisplay = findViewById(R.id.textDiary);
        selectDateButton = findViewById(R.id.btnSelectDate);
        nextButton = findViewById(R.id.btnNext);

        SharedPreferences prefs = getSharedPreferences("DiaryPrefs", MODE_PRIVATE);

        selectDateButton.setOnClickListener(view -> {
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, (view1, year, month, day) -> {
                String selectedDate = Utils.formatDate(year, month, day);

                String entry = prefs.getString(selectedDate, "No entry found for this date.");
                diaryDisplay.setText(entry);
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        });

        nextButton.setOnClickListener(view -> {
            Intent intent = new Intent(BrowserActivity.this, WebBrowserActivity.class);
            startActivity(intent);
            finish();
        });
    }
}
